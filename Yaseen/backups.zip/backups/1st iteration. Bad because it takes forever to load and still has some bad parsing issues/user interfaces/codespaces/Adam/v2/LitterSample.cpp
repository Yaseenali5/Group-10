#include "LitterSample.hpp"

// Constructor: Initializes all member variables
LitterSample::LitterSample(const std::string &location, 
                           const std::string &waterBodyType, 
                           const std::string &litterType, 
                           int litterQuantity, 
                           const std::string &complianceStatus, 
                           const std::string &date)
    : location(location), 
      waterBodyType(waterBodyType), 
      litterType(litterType), 
      litterQuantity(litterQuantity), 
      complianceStatus(complianceStatus), 
      date(date) {}

// Getter for Location
std::string LitterSample::getLocation() const {
    return location;
}

// Getter for Water Body Type
std::string LitterSample::getWaterBodyType() const {
    return waterBodyType;
}

// Getter for Litter Type
std::string LitterSample::getLitterType() const {
    return litterType;
}

// Getter for Litter Quantity
int LitterSample::getLitterQuantity() const {
    return litterQuantity;
}

// Getter for Compliance Status
std::string LitterSample::getComplianceStatus() const {
    return complianceStatus;
}

// Getter for Date
std::string LitterSample::getDate() const {
    return date;
}
