#include "LitterDataset.hpp"
#include <stdexcept>
#include <fstream>
#include <sstream>
#include <iostream>
#include <limits> // For std::numeric_limits

// Load data from a CSV file
void LitterDataset::loadData(const std::string &filename) {
    data.clear();
    std::ifstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error("Could not open file: " + filename);
    }

    std::string line;
    std::getline(file, line); // Skip the header line

    while (std::getline(file, line)) {
        std::istringstream stream(line);
        std::string location, waterBodyType, litterType, complianceStatusStr, date;
        double litterQuantity;
        bool complianceStatus;

        // Parse the columns
// Parse the columns
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `@id`
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.samplingPoint`
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.samplingPoint.notation`
std::getline(stream, location, ',');                             // sample.samplingPoint.label (Location)
std::getline(stream, date, ',');                                 // sample.sampleDateTime
std::getline(stream, litterType, ',');                           // determinand.label
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.definition`
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.notation`
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `resultQualifier.notation`
stream >> litterQuantity;                                        // result (Litter Quantity)
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip to `codedResultInterpretation.interpretation`
stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.unit.label'
stream.ignore(std::numeric_limits<std::streamsize>::max(), ',');

std::getline(stream, waterBodyType, ',');
// Validate the Water Body Type column
if (waterBodyType.empty() || waterBodyType == "<") {
    waterBodyType = "Unknown"; // Assign a default value if invalid
} else {
    // Trim leading and trailing whitespace
    waterBodyType.erase(0, waterBodyType.find_first_not_of(" \t"));
    waterBodyType.erase(waterBodyType.find_last_not_of(" \t") + 1);
}
std::getline(stream, complianceStatusStr, ',');                  // sample.isComplianceSample



        // Trim and convert compliance status to boolean
        complianceStatusStr.erase(0, complianceStatusStr.find_first_not_of(" \t")); // Trim leading whitespace
        complianceStatusStr.erase(complianceStatusStr.find_last_not_of(" \t") + 1); // Trim trailing whitespace
        complianceStatus = (complianceStatusStr == "TRUE" || complianceStatusStr == "true");

        // Log for debugging
        std::cout << "Location: " << location
                  << ", Water Body Type: " << waterBodyType
                  << ", Litter Type: " << litterType
                  << ", Litter Quantity: " << litterQuantity
                  << ", Compliance Status: " << (complianceStatus ? "Yes" : "No")
                  << ", Date: " << date << std::endl;

        data.emplace_back(location, waterBodyType, litterType, litterQuantity, 
                          complianceStatus ? "Yes" : "No", date);
    }

    file.close();
}

// Get the number of samples
int LitterDataset::size() const {
    return data.size();
}

// Access sample by index
const LitterSample& LitterDataset::operator[](int index) const {
    if (index < 0 || index >= data.size()) {
        throw std::out_of_range("Index out of range");
    }
    return data[index];
}
