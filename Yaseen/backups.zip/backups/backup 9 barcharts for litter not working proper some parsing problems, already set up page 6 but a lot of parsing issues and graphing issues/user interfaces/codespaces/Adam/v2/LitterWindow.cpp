#include "LitterWindow.hpp"
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QValueAxis>
#include <QtCharts/QChart>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QMessageBox>
#include <QDebug>

LitterWindow::LitterWindow() : QMainWindow(), tableModel(new LitterTableModel(this)), proxy(new QSortFilterProxyModel(this)) {
    setWindowTitle("Environmental Litter Indicators");
    setMinimumSize(1000, 600);
    createMainWidget();
    createStatusBar();
    addFileMenu();
    createButtons();
    createToolbar();
}

void LitterWindow::createMainWidget() {
    proxy->setSourceModel(tableModel);

    table = new QTableView();
    table->setModel(proxy);

    chartView = new QChartView();
    chartView->setRenderHint(QPainter::Antialiasing);

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(table);
    layout->addWidget(chartView);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(layout);
    setCentralWidget(centralWidget);
}

void LitterWindow::createStatusBar() {
    fileInfo = new QLabel("Current file: <none>");
    dataInfo = new QLabel("Data not loaded");
    QStatusBar *status = statusBar();
    status->addWidget(fileInfo);
    status->addWidget(dataInfo);
}

void LitterWindow::addFileMenu() {
    openAction = new QAction("&Open...", this);
    openAction->setShortcut(QKeySequence::Open);
    connect(openAction, &QAction::triggered, this, &LitterWindow::setDataLocation);

    closeAction = new QAction("&Quit", this);
    closeAction->setShortcut(QKeySequence::Quit);
    connect(closeAction, &QAction::triggered, this, &LitterWindow::close);

    QMenu *fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction(openAction);
    fileMenu->addAction(closeAction);
}

void LitterWindow::createButtons() {
    loadButton = new QPushButton("Load Data");
    connect(loadButton, &QPushButton::clicked, this, &LitterWindow::loadCSV);

    chartButton = new QPushButton("Generate Chart");
    connect(chartButton, &QPushButton::clicked, this, &LitterWindow::loadGraph);
}

void LitterWindow::createToolbar() {
    QToolBar *toolbar = new QToolBar();

    locationFilter = new QComboBox();
    connect(locationFilter, &QComboBox::currentTextChanged, this, &LitterWindow::filterByLocation);

    litterTypeFilter = new QComboBox();
    connect(litterTypeFilter, &QComboBox::currentTextChanged, this, &LitterWindow::filterByLitterType);

    toolbar->addWidget(loadButton);
    toolbar->addWidget(new QLabel("Location:"));
    toolbar->addWidget(locationFilter);
    toolbar->addWidget(new QLabel("Litter Type:"));
    toolbar->addWidget(litterTypeFilter);
    toolbar->addWidget(chartButton);

    addToolBar(Qt::TopToolBarArea, toolbar);
}

void LitterWindow::setDataLocation() {
    QString path = QFileDialog::getOpenFileName(this, "Open CSV File", ".", "CSV files (*.csv)");
    if (path.isEmpty()) {
        QMessageBox::critical(this, "Error", "Please select a valid CSV file.");
        return;
    }
    fileInfo->setText(QFileInfo(path).fileName());
    filename = path;
}

void LitterWindow::loadCSV() {
    if (filename.isEmpty()) {
        QMessageBox::critical(this, "Error", "No file selected.");
        return;
    }

    try {
        dataset.loadData(filename.toStdString());
        tableModel->setDataset(&dataset);
        dataInfo->setText("Data Loaded.");
        loadDataToTable();
    } catch (const std::exception &e) {
        QMessageBox::critical(this, "Error", e.what());
    }
}

void LitterWindow::loadDataToTable() {
    locationFilter->clear();
    litterTypeFilter->clear();

    locationFilter->addItem("All Locations");
    litterTypeFilter->addItem("All Types");

    QSet<QString> locations, litterTypes;

    for (int i = 0; i < dataset.size(); ++i) {
        const auto &sample = dataset[i];
        locations.insert(QString::fromStdString(sample.getLocation()));
        litterTypes.insert(QString::fromStdString(sample.getLitterType()));
    }

    locationFilter->addItems(locations.values());
    litterTypeFilter->addItems(litterTypes.values());
}

void LitterWindow::filterByLocation(const QString &location) {
    proxy->setFilterKeyColumn(0);
    proxy->setFilterFixedString(location == "All Locations" ? "" : location);
}

void LitterWindow::filterByLitterType(const QString &litterType) {
    proxy->setFilterKeyColumn(2);
    proxy->setFilterFixedString(litterType == "All Types" ? "" : litterType);
}

void LitterWindow::loadGraph() {
    // Ensure the dataset is not empty
    if (dataset.size() == 0) {
        QMessageBox::warning(this, "No Data", "Dataset is empty. Please load data before generating a chart.");
        return;
    }

    // Check if chartView is properly initialized
    if (!chartView) {
        QMessageBox::critical(this, "Error", "Chart view is not initialized.");
        return;
    }

    // Clear any existing chart
    if (chartView->chart()) {
        chartView->chart()->deleteLater();
    }

    // Create a new bar series
    QBarSeries *series = new QBarSeries();

    // Aggregate litter counts by type
    QHash<QString, double> litterCounts;

    for (int i = 0; i < dataset.size(); ++i) {
        try {
            const auto &sample = dataset[i];
            QString type = QString::fromStdString(sample.getLitterType());
            double quantity = sample.getLitterQuantity();

            if (quantity >= 0) { // Ensure only valid quantities are aggregated
                litterCounts[type] += quantity;
            }
        } catch (const std::exception &e) {
            qDebug() << "Error accessing dataset at index" << i << ":" << e.what();
            QMessageBox::warning(this, "Data Error", "Error accessing dataset. Please check the data file.");
            return;
        }
    }

    // Check if there is data to display
    if (litterCounts.isEmpty()) {
        QMessageBox::warning(this, "No Data", "No valid data available to generate the chart.");
        return;
    }

    // Add data to the bar series
    for (auto it = litterCounts.begin(); it != litterCounts.end(); ++it) {
        QBarSet *set = new QBarSet(it.key());
        *set << it.value(); // Add aggregated value
        series->append(set);
    }

    // Create and configure the chart
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Litter Types Distribution");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    // Configure X-axis with litter types
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(litterCounts.keys());
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    // Configure Y-axis with dynamic range
    QValueAxis *axisY = new QValueAxis();
    axisY->setTitleText("Litter Quantity");
    double maxQuantity = *std::max_element(litterCounts.values().begin(), litterCounts.values().end());
    axisY->setRange(0, maxQuantity * 1.1); // Add 10% padding
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    // Set the chart to the chart view
    chartView->setChart(chart);

    // Debugging output to verify data
    qDebug() << "Chart created with the following data:";
    for (auto it = litterCounts.begin(); it != litterCounts.end(); ++it) {
        qDebug() << "Type:" << it.key() << ", Quantity:" << it.value();
    }
}
