#pragma once

#include <QTranslator>
#include <QWidget>
#include <QPushButton>
#include <QComboBox>
#include <QVBoxLayout>

class homePage : public QWidget {
    Q_OBJECT

public:
    explicit homePage(QWidget *parent = nullptr);

signals:
    void buttonClicked(const QString &pageId);  // Signal for button clicks
    void languageChanged(const QString &languageCode); // Signal for language changes

public slots:
    void setupUI(); // Rebuild UI on language change

private:
    QVBoxLayout *mainLayout;
};




