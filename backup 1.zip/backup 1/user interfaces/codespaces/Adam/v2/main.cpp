#include <QtWidgets>
#include <iostream>
#include "rawwindow.hpp"
#include "POPwindow.hpp"
#include "LitterWindow.hpp" // Include the LitterWindow header

int main(int argc, char* argv[]) {
    int n;
    std::cout << "Enter number (0 = raw data page, 1 = POP page, 2 = Litter Indicators page): ";
    std::cin >> n;

    QApplication app(argc, argv);

    if (n == 0) {
        RawWindow window;
        window.show();
        return app.exec();
    } else if (n == 1) {
        POPWindow window;
        window.show();
        return app.exec();
    } else if (n == 2) { // Add the Litter Indicators option
        LitterWindow window;
        window.show();
        return app.exec();
    } else {
        std::cerr << "Invalid option. Exiting." << std::endl;
        return -1;
    }
}

