#include "LitterDataset.hpp"
#include <stdexcept>
#include <fstream>
#include <sstream>
#include <iostream>
#include <limits> // For std::numeric_limits
#include <regex>  // For trimming and sanitizing inputs

// Helper function to trim whitespace
std::string trim(const std::string &str) {
    const std::regex trimRegex("^\\s+|\\s+$");
    return std::regex_replace(str, trimRegex, "");
}

// Load data from a CSV file
void LitterDataset::loadData(const std::string &filename) {
    data.clear();
    std::ifstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error("Could not open file: " + filename);
    }

    std::string line;
    std::getline(file, line); // Skip the header line

    size_t processedRecords = 0;
    while (std::getline(file, line)) {
        std::istringstream stream(line);
        std::string location, waterBodyType, litterType, complianceStatusStr, date;
        double litterQuantity = 0.0;
        bool complianceStatus;

        try {
            // Parse the columns
            std::getline(stream, location, ',');                    // @id (Location)
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.samplingPoint`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.samplingPoint.notation`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.samplingPoint.label`
            std::getline(stream, date, ',');                        // sample.sampleDateTime
            std::getline(stream, litterType, ',');                  // determinand.label
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.definition`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.notation`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `resultQualifier.notation`
            stream >> litterQuantity;                               // result (Litter Quantity)
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip to `codedResultInterpretation.interpretation`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.unit.label`
            std::getline(stream, waterBodyType, ',');               // sample.sampledMaterialType.label
            std::getline(stream, complianceStatusStr, ',');         // sample.isComplianceSample

            // Trim inputs
            location = trim(location);
            waterBodyType = trim(waterBodyType);
            litterType = trim(litterType);
            complianceStatusStr = trim(complianceStatusStr);
            date = trim(date);

            // Parse compliance status
            complianceStatus = (complianceStatusStr == "TRUE" || complianceStatusStr == "true");

            // Add the sample to the dataset
            data.emplace_back(location, waterBodyType, litterType, litterQuantity,
                              complianceStatus ? "Yes" : "No", date);

            // Count processed records and provide feedback
            processedRecords++;
            if (processedRecords % 10000 == 0) {
                std::cout << "Processed " << processedRecords << " records..." << std::endl;
            }
        } catch (const std::exception &e) {
            std::cerr << "Error parsing line: " << line << " -> " << e.what() << std::endl;
        }
    }

    std::cout << "Finished loading " << processedRecords << " records." << std::endl;
    file.close();
}

// Get the number of samples
int LitterDataset::size() const {
    return data.size();
}

// Access sample by index
const LitterSample& LitterDataset::operator[](int index) const {
    if (index < 0 || index >= data.size()) {
        throw std::out_of_range("Index out of range");
    }
    return data[index];
}