#include <QtWidgets>
#include <QTranslator>
#include <QApplication>
#include <QDebug>
#include <iostream>
#include "rawwindow.hpp"
#include "homePage.hpp" // Ensure homePage is included

int main(int argc, char* argv[])
{
    QString StyleSheet = R"(
        QMainWindow {
            background-color: #434a5e; /* Slightly blue dark color */
            color: #e0e0e0;           /* Light grey text */
        }

        QMenuBar {
            background-color: #4b5165; 
            color: #e0e0e0;           /* Text */
            border: none;
        }

        QMenuBar::item {
            background-color: transparent;
            padding: 5px 10px;
        }

        QMenuBar::item:selected {
            background-color: #57607a; /* Hover */
        }

        QMenuBar::item:pressed {
            background-color: #68758d;
        }

        QToolBar {
            background-color: #4b5165; 
            border: none;
        }

        QToolBar QToolButton {
            background-color: #52596e;
            border: 1px solid #68758d; 
            border-radius: 4px;
            padding: 5px;
            color: #e0e0e0;           /* Text */
        }

        QToolBar QToolButton:hover {
            background-color: #57607a; 
        }

        QToolBar QToolButton:pressed {
            background-color: #68758d;
        }

        QMenu {
            background-color: #4b5165; /* Same as menu bar and toolbar */
            color: #e0e0e0;           /* Text */
            border: 1px solid #68758d;
        }

        QMenu::item:selected {
            background-color: #57607a; /* On hover */
        }

        QPushButton {
            background-color: #52596e; /* Same as toolbar buttons */
            color: #e0e0e0;           /* Text */
            border: 1px solid #68758d; /* Border */
            border-radius: 4px;
            padding: 8px 16px;
        }

        QPushButton:hover {
            background-color: #57607a;
        }

        QPushButton:pressed {
            background-color: #68758d;
        }

        QStatusBar {
            background-color: #4b5165; 
            color: #e0e0e0;           /* Light grey text */
            border-top: 1px solid #68758d; /* border */
        }

        QStatusBar::item {
            border: none;
            background: transparent;
        }

        QToolBar::separator {
            background-color: #68758d; 
            width: 2px;               /* Thickness */
            height: 4px;             /* Height */
            margin: 5px;              /* Spacing */
        }

        QLabel {
            color: #e0e0e0;
        }
    )";

    QApplication app(argc, argv);
    app.setStyleSheet(StyleSheet);

    // Set the font
    QFont font;
    font.setFamily("Segoe UI");
    font.setPointSize(10);
    font.setWeight(QFont::Bold);
    app.setFont(font);

    // Translation support
    QTranslator translator;
    QString currentLanguage = "en"; // Default language

    // Function to load translations
    auto loadLanguage = [&](const QString &lang) {
        QString translationPath = QCoreApplication::applicationDirPath() + "/translations/lango_" + lang + ".qm";
        if (translator.load(translationPath)) {
            app.installTranslator(&translator);
            qDebug() << "Loaded language:" << lang;
        } else {
            qDebug() << "Failed to load translation for:" << lang;
        }
    };

    // Main window
    RawWindow window;
    window.setWindowTitle(QObject::tr("Water Quality Monitor"));

    // Create the homePage instance
    homePage *page = new homePage(&window);
    // Connect navigation signals
    QObject::connect(page, &homePage::buttonClicked, [&](const QString &pageId) {
        qDebug() << "Navigating to:" << pageId;

        if (pageId == "Page1") {
            qDebug() << "Navigated to Pollutant Overview";
        } else if (pageId == "Page2") {
            qDebug() << "Navigated to Persistent Organic Pollutants (POPs)";
        } else if (pageId == "Page3") {
            qDebug() << "Navigated to Environmental Litter Indicators";
        } else if (pageId == "Page4") {
            qDebug() << "Navigated to Fluorinated Compounds";
        } else if (pageId == "Page5") {
            qDebug() << "Navigated to Compliance Dashboard";
        } else if (pageId == "Page6") {
            qDebug() << "Navigated to Raw Data";
        }
    });

    // Menu bar for language selection
    QMenuBar *menuBar = new QMenuBar(&window);
    QMenu *languageMenu = menuBar->addMenu(QObject::tr("Language"));

    QAction *englishAction = new QAction(QObject::tr("English"), &window);
    QAction *frenchAction = new QAction(QObject::tr("Français"), &window);

    languageMenu->addAction(englishAction);
    languageMenu->addAction(frenchAction);

    // Connect language actions to dynamically reload translations
    QObject::connect(englishAction, &QAction::triggered, [&]() {
        app.removeTranslator(&translator);
        loadLanguage("en");
        window.setWindowTitle(QObject::tr("Water Quality Monitor"));
        page->setupUI(); // Rebuild the homePage UI
        window.repaint();
    });

    QObject::connect(frenchAction, &QAction::triggered, [&]() {
        app.removeTranslator(&translator);
        loadLanguage("fr");
        window.setWindowTitle(QObject::tr("Water Quality Monitor"));
        page->setupUI(); // Rebuild the homePage UI
        window.repaint();
    });

    // Set the menu bar to the window
    window.setMenuBar(menuBar);

    // Load the default language
    loadLanguage(currentLanguage);

    // Set homePage to the main window layout
    window.setCentralWidget(page);

    // Show the main window
    window.showMaximized();

    return app.exec();
}