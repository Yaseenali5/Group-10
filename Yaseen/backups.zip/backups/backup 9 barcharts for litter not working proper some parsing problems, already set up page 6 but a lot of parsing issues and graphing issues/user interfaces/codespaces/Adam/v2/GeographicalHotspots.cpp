#include "GeographicalHotspots.hpp"
#include <QtCharts/QScatterSeries>
#include <QtCharts/QChart>
#include <QFileDialog>
#include <QMessageBox>
#include <QVBoxLayout>
#include <QToolBar>
#include <QStatusBar>

GeographicalHotspots::GeographicalHotspots(QWidget *parent)
    : QMainWindow(parent), chartView(new QChartView(this)), tableView(new QTableView(this)) {
    setWindowTitle("Geographical Hotspots");
    setMinimumSize(1000, 600);
    createMainWidget();
    createToolbar();
    createStatusBar();
}

void GeographicalHotspots::createMainWidget() {
    chartView->setRenderHint(QPainter::Antialiasing);

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(chartView);
    layout->addWidget(tableView);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(layout);
    setCentralWidget(centralWidget);
}

void GeographicalHotspots::createToolbar() {
    QToolBar *toolbar = new QToolBar();

    loadButton = new QPushButton("Load Data");
    connect(loadButton, &QPushButton::clicked, this, &GeographicalHotspots::loadCSV);

    locationFilter = new QComboBox();
    connect(locationFilter, &QComboBox::currentTextChanged, this, &GeographicalHotspots::filterByLocation);

    pollutantFilter = new QComboBox();
    connect(pollutantFilter, &QComboBox::currentTextChanged, this, &GeographicalHotspots::filterByPollutant);

    toolbar->addWidget(loadButton);
    toolbar->addWidget(new QLabel("Location:"));
    toolbar->addWidget(locationFilter);
    toolbar->addWidget(new QLabel("Pollutant:"));
    toolbar->addWidget(pollutantFilter);

    addToolBar(Qt::TopToolBarArea, toolbar);
}

void GeographicalHotspots::createStatusBar() {
    statusLabel = new QLabel("No data loaded.");
    statusBar()->addWidget(statusLabel);
}

void GeographicalHotspots::loadCSV() {
    QString filePath = QFileDialog::getOpenFileName(this, "Open CSV File", ".", "CSV files (*.csv)");
    if (filePath.isEmpty()) {
        QMessageBox::warning(this, "Error", "No file selected.");
        return;
    }

    try {
        dataset.loadData(filePath.toStdString());
        loadDataToTable();
        updateChart();
        statusLabel->setText("Data loaded successfully.");
    } catch (const std::exception &e) {
        QMessageBox::critical(this, "Error", e.what());
    }
}


void GeographicalHotspots::loadDataToTable() {
    // Populate table view with dataset (implementation depends on dataset structure)
    // Populate filters for location and pollutant
    locationFilter->clear();
    pollutantFilter->clear();
    locationFilter->addItem("All Locations");
    pollutantFilter->addItem("All Pollutants");

    QSet<QString> locations, pollutants;

    for (int i = 0; i < dataset.size(); ++i) {
        const auto &entry = dataset[i];
        locations.insert(QString::fromStdString(entry.getLocation()));
        pollutants.insert(QString::fromStdString(entry.getPollutant()));
    }

    locationFilter->addItems(locations.values());
    pollutantFilter->addItems(pollutants.values());
}

void GeographicalHotspots::updateChart() {
    QScatterSeries *series = new QScatterSeries();
    series->setMarkerSize(10);

    for (int i = 0; i < dataset.size(); ++i) {
        const auto &entry = dataset[i];
        double x = entry.getEasting();
        double y = entry.getNorthing();
        series->append(x, y);
    }

    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Geographical Hotspots");
    chart->createDefaultAxes();

    chartView->setChart(chart);
}

void GeographicalHotspots::filterByLocation(const QString &location) {
    QScatterSeries *filteredSeries = new QScatterSeries();
    filteredSeries->setMarkerSize(10);

    for (int i = 0; i < dataset.size(); ++i) {
        const auto &entry = dataset[i];
        if (location == "All Locations" || QString::fromStdString(entry.getLocation()) == location) {
            filteredSeries->append(entry.getEasting(), entry.getNorthing());
        }
    }

    QChart *chart = new QChart();
    chart->addSeries(filteredSeries);
    chart->setTitle("Geographical Hotspots (Filtered by Location)");
    chart->createDefaultAxes();

    chartView->setChart(chart);
}

void GeographicalHotspots::filterByPollutant(const QString &pollutant) {
    QScatterSeries *filteredSeries = new QScatterSeries();
    filteredSeries->setMarkerSize(10);

    for (int i = 0; i < dataset.size(); ++i) {
        const auto &entry = dataset[i];
        if (pollutant == "All Pollutants" || QString::fromStdString(entry.getPollutant()) == pollutant) {
            filteredSeries->append(entry.getEasting(), entry.getNorthing());
        }
    }

    QChart *chart = new QChart();
    chart->addSeries(filteredSeries);
    chart->setTitle("Geographical Hotspots (Filtered by Pollutant)");
    chart->createDefaultAxes();

    chartView->setChart(chart);
}
