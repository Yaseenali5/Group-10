#include "LitterTableModel.hpp"
#include "LitterSample.hpp"
#include <QFont>
#include <QBrush>

// Constructor: Initializes the table model
LitterTableModel::LitterTableModel(QObject *parent) 
    : QAbstractTableModel(parent), dataset(nullptr) {}

// Sets the dataset and resets the model
void LitterTableModel::setDataset(LitterDataset *newDataset) {
    beginResetModel();
    dataset = newDataset;
    endResetModel();
}

// Returns the number of rows (samples) in the dataset
int LitterTableModel::rowCount(const QModelIndex &parent) const {
    if (parent.isValid() || !dataset) {
        return 0;
    }
    return dataset->size();
}

// Returns the number of columns (attributes) in a sample
int LitterTableModel::columnCount(const QModelIndex &parent) const {
    if (parent.isValid() || !dataset) {
        return 0;
    }
    return 6; // Attributes: Location, Water Body Type, Litter Type, Litter Quantity, Compliance Status, Date
}

// Provides data for the table cells
QVariant LitterTableModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid() || !dataset) {
        return QVariant();
    }

    const LitterSample &sample = (*dataset)[index.row()];

    if (role == Qt::DisplayRole) { // Data to display in the table cells
        switch (index.column()) {
            case 0: return QString::fromStdString(sample.getLocation());          // Location
            case 1: return QString::fromStdString(sample.getWaterBodyType());     // Water Body Type
            case 2: return QString::fromStdString(sample.getLitterType());        // Litter Type
            case 3: return QString::number(sample.getLitterQuantity(), 'f', 4);  // Litter Quantity
            case 4: return QString::fromStdString(sample.getComplianceStatus());  // Compliance Status
            case 5: return QString::fromStdString(sample.getDate());              // Date
            default: return QVariant();
        }
    }

    if (role == Qt::TextAlignmentRole) { // Center-align text in the cells
        return Qt::AlignCenter;
    }

    if (role == Qt::ForegroundRole && index.column() == 4) { // Compliance status color coding
        QString compliance = QString::fromStdString(sample.getComplianceStatus());
        if (compliance == "Yes") {
            return QBrush(Qt::green);
        } else if (compliance == "No") {
            return QBrush(Qt::red);
        }
    }

    return QVariant();
}

// Provides headers for the table
QVariant LitterTableModel::headerData(int section, Qt::Orientation orientation, int role) const {
    if (role != Qt::DisplayRole) {
        return QVariant();
    }

    if (orientation == Qt::Horizontal) {
        switch (section) {
            case 0: return "Location";
            case 1: return "Water Body Type";
            case 2: return "Litter Type";
            case 3: return "Litter Quantity";
            case 4: return "Compliance Status";
            case 5: return "Date";
            default: return QVariant();
        }
    }

    return QVariant();
}
