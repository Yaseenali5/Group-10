#ifndef GEOGRAPHICALHOTSPOTS_HPP
#define GEOGRAPHICALHOTSPOTS_HPP

#include <QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QScatterSeries>
#include <QComboBox>
#include <QTableView>
#include <QPushButton>
#include <QLabel>
#include "HotspotDataset.hpp"

class GeographicalHotspots : public QMainWindow {
    Q_OBJECT

public:
    GeographicalHotspots(QWidget *parent = nullptr);

private slots:
    void loadCSV();
    void updateChart();
    void filterByLocation(const QString &location);
    void filterByPollutant(const QString &pollutant);

private:
    void createMainWidget();
    void createToolbar();
    void createStatusBar();
    void loadDataToTable();

    HotspotDataset dataset;
    QChartView *chartView;
    QTableView *tableView;
    QComboBox *locationFilter;
    QComboBox *pollutantFilter;
    QPushButton *loadButton;
    QLabel *statusLabel;
};

#endif // GEOGRAPHICALHOTSPOTS_HPP
