#pragma once

#include <QtWidgets>
#include <QtCharts/QChartView>
#include <QSortFilterProxyModel>
#include "LitterTableModel.hpp"
#include "LitterDataset.hpp"

class LitterWindow : public QMainWindow {
    Q_OBJECT

public:
    LitterWindow();

private:
    void createMainWidget();
    void createStatusBar();
    void addFileMenu();
    void createButtons();
    void createToolbar();
    void setDataLocation();
    void loadCSV();
    void loadDataToTable();
    void filterByLocation(const QString &location);
    void filterByLitterType(const QString &litterType);
    void loadGraph();

    LitterDataset dataset;
    LitterTableModel *tableModel;
    QSortFilterProxyModel *proxy;
    QTableView *table;
    QChartView *chartView;
    QComboBox *locationFilter;
    QComboBox *litterTypeFilter;
    QPushButton *loadButton;
    QPushButton *chartButton;
    QLabel *fileInfo;
    QLabel *dataInfo;
    QString filename;

    QAction *openAction; // Added declaration
    QAction *closeAction; // Added declaration
};
