#pragma once

#include <vector>
#include <string>
#include "LitterSample.hpp"

class LitterDataset {
public:
    LitterDataset() = default;
    void loadData(const std::string &filename);
    const LitterSample &operator[](int index) const;
    int size() const;

private:
    std::vector<LitterSample> data;
};
