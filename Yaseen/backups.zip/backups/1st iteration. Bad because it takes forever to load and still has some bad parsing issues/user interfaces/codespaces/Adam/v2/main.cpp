#include <QtWidgets>
#include <iostream>
#include "rawwindow.hpp"
#include "POPwindow.hpp"
#include "LitterWindow.hpp" // Include the LitterWindow header

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);

    int n;
    std::cout << "Enter number (0 = raw data page, 1 = POP page, 2 = Litter Indicators page): ";
    std::cin >> n;

    if (n == 0) {
        RawWindow window;
        window.show();
        return app.exec();
    } else if (n == 1) {
        POPWindow window;
        window.show();
        return app.exec();
    } else if (n == 2) { // Litter Indicators option
        LitterWindow window;
        window.show();
        return app.exec();
    } else {
        std::cerr << "Invalid option. Please enter 0, 1, or 2. Exiting." << std::endl;
        return EXIT_FAILURE;
    }
}
