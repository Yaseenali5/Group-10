#pragma once

#include <QtWidgets>
#include <QSortFilterProxyModel>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QPieSeries>
#include "WQDataset.hpp"
#include "WQTableModel.hpp"

class LitterWindow : public QMainWindow {
    Q_OBJECT

public:
    LitterWindow();

private:
    void createMainWidget();
    void createFileSelectors();
    void createButtons();
    void createToolbar();
    void createStatusBar();
    void addFileMenu();
    void loadGraph();
    void updateChart(const QString &location, const QString &litterType);
    void loadDataToTable();

    QAction *openAction;
    QAction *closeAction;
    QMenu *fileMenu;
    QLabel *fileInfo;
    QLabel *dataInfo;
    QString filename;

    QPushButton *loadButton;
    QPushButton *chartButton;

    QComboBox *locationFilter;
    QComboBox *litterTypeFilter;

    QTableView *table;
    QSortFilterProxyModel *proxy;
    WQTableModel tableModel;

    QChartView *chartView;

    WQDataset dataset;

private slots:
    void setDataLocation();
    void loadCSV();
    void filterByLocation(const QString &location);
    void filterByLitterType(const QString &litterType);
};
