#ifndef HOTSPOTDATASET_HPP
#define HOTSPOTDATASET_HPP

#include <vector>
#include <string>

class HotspotEntry {
public:
    HotspotEntry(const std::string &location, const std::string &pollutant, double level,
                 double easting, double northing, const std::string &complianceStatus)
        : location(location), pollutant(pollutant), level(level),
          easting(easting), northing(northing), complianceStatus(complianceStatus) {}

    const std::string &getLocation() const { return location; }
    const std::string &getPollutant() const { return pollutant; }
    double getLevel() const { return level; }
    double getEasting() const { return easting; }
    double getNorthing() const { return northing; }
    const std::string &getComplianceStatus() const { return complianceStatus; }

private:
    std::string location;
    std::string pollutant;
    double level;
    double easting;
    double northing;
    std::string complianceStatus;
};

class HotspotDataset {
public:
    void loadData(const std::string &filename);
    const HotspotEntry &operator[](size_t index) const;
    size_t size() const { return data.size(); }

private:
    std::vector<HotspotEntry> data;
};

#endif // HOTSPOTDATASET_HPP
