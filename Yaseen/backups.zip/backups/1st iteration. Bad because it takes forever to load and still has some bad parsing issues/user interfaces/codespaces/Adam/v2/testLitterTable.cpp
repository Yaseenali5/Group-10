#include <QApplication>
#include <QTableView>
#include "LitterDataset.hpp"
#include "LitterTableModel.hpp"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // Load dataset
    LitterDataset dataset;
    dataset.loadData("test.csv"); // Replace with your CSV path

    // Initialize table model
    LitterTableModel model;
    model.setDataset(&dataset);

    // Display in a table view
    QTableView view;
    view.setModel(&model);
    view.resize(800, 600);
    view.show();

    return app.exec();
}
