#pragma once

#include <string>

class LitterSample {
public:
    // Constructor
    LitterSample(const std::string &location, 
                 const std::string &waterBodyType, 
                 const std::string &litterType, 
                 int litterQuantity, 
                 const std::string &complianceStatus, 
                 const std::string &date);

    // Getters
    std::string getLocation() const;
    std::string getWaterBodyType() const;
    std::string getLitterType() const;
    int getLitterQuantity() const;
    std::string getComplianceStatus() const;
    std::string getDate() const;

private:
    // Member variables
    std::string location;
    std::string waterBodyType;
    std::string litterType;
    int litterQuantity;
    std::string complianceStatus;
    std::string date;
};
