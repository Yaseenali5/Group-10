#include "LitterWindow.hpp"
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QPieSeries>
#include <QtCharts/QChart>
#include <QtCharts/QValueAxis>

LitterWindow::LitterWindow() : QMainWindow(), tableModel(new LitterTableModel(this)), proxy(new QSortFilterProxyModel(this)) {
    setWindowTitle("Environmental Litter Indicators");
    setMinimumSize(1000, 600);
    createMainWidget();
    createStatusBar();
    addFileMenu();
    createButtons();
    createToolbar();
}

void LitterWindow::createMainWidget() {
    proxy->setSourceModel(tableModel);

    table = new QTableView();
    table->setModel(proxy);

    chartView = new QChartView();
    chartView->setRenderHint(QPainter::Antialiasing);

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(table);
    layout->addWidget(chartView);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(layout);
    setCentralWidget(centralWidget);
}

void LitterWindow::createStatusBar() {
    fileInfo = new QLabel("Current file: <none>");
    dataInfo = new QLabel("Data not loaded");
    QStatusBar *status = statusBar();
    status->addWidget(fileInfo);
    status->addWidget(dataInfo);
}

void LitterWindow::addFileMenu() {
    openAction = new QAction("&Open...", this);
    openAction->setShortcut(QKeySequence::Open);
    connect(openAction, &QAction::triggered, this, &LitterWindow::setDataLocation);

    closeAction = new QAction("&Quit", this);
    closeAction->setShortcut(QKeySequence::Quit);
    connect(closeAction, &QAction::triggered, this, &LitterWindow::close);

    QMenu *fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction(openAction);
    fileMenu->addAction(closeAction);
}

void LitterWindow::createButtons() {
    loadButton = new QPushButton("Load Data");
    connect(loadButton, &QPushButton::clicked, this, &LitterWindow::loadCSV);

    chartButton = new QPushButton("Generate Chart");
    connect(chartButton, &QPushButton::clicked, this, &LitterWindow::loadGraph);
}

void LitterWindow::createToolbar() {
    QToolBar *toolbar = new QToolBar();

    locationFilter = new QComboBox();
    connect(locationFilter, &QComboBox::currentTextChanged, this, &LitterWindow::filterByLocation);

    litterTypeFilter = new QComboBox();
    connect(litterTypeFilter, &QComboBox::currentTextChanged, this, &LitterWindow::filterByLitterType);

    toolbar->addWidget(loadButton);
    toolbar->addWidget(new QLabel("Location:"));
    toolbar->addWidget(locationFilter);
    toolbar->addWidget(new QLabel("Litter Type:"));
    toolbar->addWidget(litterTypeFilter);
    toolbar->addWidget(chartButton);

    addToolBar(Qt::TopToolBarArea, toolbar);
}

void LitterWindow::setDataLocation() {
    QString path = QFileDialog::getOpenFileName(this, "Open CSV File", ".", "CSV files (*.csv)");
    if (path.isEmpty()) {
        QMessageBox::critical(this, "Error", "Please select a valid CSV file.");
        return;
    }
    fileInfo->setText(QFileInfo(path).fileName());
    filename = path;
}

void LitterWindow::loadCSV() {
    if (filename.isEmpty()) {
        QMessageBox::critical(this, "Error", "No file selected.");
        return;
    }

    try {
        dataset.loadData(filename.toStdString());
        tableModel->setDataset(&dataset);
        dataInfo->setText("Data Loaded.");
        loadDataToTable();
    } catch (const std::exception &e) {
        QMessageBox::critical(this, "Error", e.what());
    }
}

void LitterWindow::loadDataToTable() {
    locationFilter->clear();
    litterTypeFilter->clear();

    locationFilter->addItem("All Locations");
    litterTypeFilter->addItem("All Types");

    QSet<QString> locations, litterTypes;

    for (int i = 0; i < dataset.size(); ++i) {
        const auto &sample = dataset[i];
        locations.insert(QString::fromStdString(sample.getLocation()));
        litterTypes.insert(QString::fromStdString(sample.getLitterType()));
    }

    locationFilter->addItems(locations.values());
    litterTypeFilter->addItems(litterTypes.values());
}

void LitterWindow::filterByLocation(const QString &location) {
    proxy->setFilterKeyColumn(0);
    proxy->setFilterFixedString(location == "All Locations" ? "" : location);
}

void LitterWindow::filterByLitterType(const QString &litterType) {
    proxy->setFilterKeyColumn(2);
    proxy->setFilterFixedString(litterType == "All Types" ? "" : litterType);
}

void LitterWindow::loadGraph() {
    QBarSeries *series = new QBarSeries();

    QHash<QString, int> litterCounts;

    for (int i = 0; i < dataset.size(); ++i) {
        const auto &sample = dataset[i];
        QString type = QString::fromStdString(sample.getLitterType());
        litterCounts[type] += sample.getLitterQuantity();
    }

    for (auto it = litterCounts.begin(); it != litterCounts.end(); ++it) {
        QBarSet *set = new QBarSet(it.key());
        *set << it.value();
        series->append(set);
    }

    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Litter Types Distribution");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    chartView->setChart(chart);
}
