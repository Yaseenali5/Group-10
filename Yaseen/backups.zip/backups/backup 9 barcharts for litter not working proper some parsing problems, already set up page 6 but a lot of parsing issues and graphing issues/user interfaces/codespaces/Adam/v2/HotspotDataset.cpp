#include "HotspotDataset.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>


const HotspotEntry& HotspotDataset::operator[](size_t index) const {
    if (index >= data.size()) {
        throw std::out_of_range("Index out of range in HotspotDataset.");
    }
    return data[index];
}
void HotspotDataset::loadData(const std::string &filename) {
    data.clear();

    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file: " + filename);
    }

    std::string line;
    std::getline(file, line); // Skip the header line

    size_t rowNumber = 0;
    while (std::getline(file, line)) {
        ++rowNumber;
        std::istringstream stream(line);

        std::string location, pollutant, complianceStatus;
        double level = 0.0, easting = 0.0, northing = 0.0;

        try {
            // Parse columns
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `@id`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.samplingPoint`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.samplingPoint.notation`
            std::getline(stream, location, ',');                             // sample.samplingPoint.label

            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `sample.sampleDateTime`
            std::getline(stream, pollutant, ',');                           // determinand.label

            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.definition`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.notation`
            std::string levelStr;
            std::getline(stream, levelStr, ',');                            // result (level)

            if (levelStr == "<" || levelStr.empty()) {
                level = 0.0; // Assign default for invalid values
            } else {
                level = std::stod(levelStr);
            }

            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `codedResultInterpretation.interpretation`
            stream.ignore(std::numeric_limits<std::streamsize>::max(), ','); // Skip `determinand.unit.label`

            std::string eastingStr, northingStr;
            std::getline(stream, eastingStr, ',');
            easting = eastingStr.empty() ? 0.0 : std::stod(eastingStr);

            std::getline(stream, northingStr, ',');
            northing = northingStr.empty() ? 0.0 : std::stod(northingStr);

            std::getline(stream, complianceStatus, ','); // sample.isComplianceSample

            // Validate required fields
            if (location.empty() || pollutant.empty() || easting == 0.0 || northing == 0.0) {
                std::cerr << "Invalid data at row: " << rowNumber << std::endl;
                continue;
            }

            // Add entry to the dataset
            data.emplace_back(location, pollutant, level, easting, northing, complianceStatus);
        } catch (const std::exception &e) {
            std::cerr << "Error processing row: " << rowNumber << ", " << e.what() << std::endl;
            std::cerr << "Raw line: " << line << std::endl;
        }
    }

    file.close();

    std::cout << "Total rows processed: " << rowNumber << std::endl;
    std::cout << "Total valid rows loaded: " << data.size() << std::endl;
}
